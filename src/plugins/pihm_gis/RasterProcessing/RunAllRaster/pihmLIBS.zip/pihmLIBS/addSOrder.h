#ifndef ADDSORDER
#define ADDSORDER

void addSOrder(const char *dbfFileName, const char *shpFileName);

#endif