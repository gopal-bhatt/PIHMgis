#ifndef EXTRACTRIVER
#define EXTRACTRIVER

void extractRiver4mTIN(const char* shpFileName, const char* dbfFileName, const char* eleFileName, const char* nodeFileName, const char* neighFileName, const char *newshp, const char *newdbf);

#endif