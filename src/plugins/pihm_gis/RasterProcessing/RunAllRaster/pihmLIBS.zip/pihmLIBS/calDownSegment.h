#ifndef DOWNSEGMENT
#define DOWNSEGMENT

void calDownSegment(const char* dbfFileName, int BC);

#endif
