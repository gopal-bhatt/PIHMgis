#ifndef ADDTOFROMNODE
#define ADDTOFROMNODE

void addToFromNode(const char *dbfFileName, const char *shpFileName);

#endif