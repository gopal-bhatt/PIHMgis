#ifndef POINT
#define POINT

	struct Point{
		double x, y;
	};

	int equalPoint(Point p1, Point p2);
#endif
