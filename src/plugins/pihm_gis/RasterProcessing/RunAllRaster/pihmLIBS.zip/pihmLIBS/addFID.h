#ifndef ADDFID
#define ADDFID

void addFID(const char *dbfFileName);

#endif