#include <iostream.h>

struct Line{
	int pt1, pt2;
};

