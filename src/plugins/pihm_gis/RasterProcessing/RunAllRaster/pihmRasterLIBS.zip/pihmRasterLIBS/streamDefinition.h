int streamDefinition(char *aread8File, char *orderFile, char *rivFile, int method, float threshold);
