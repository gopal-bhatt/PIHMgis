int streamSegmentationShp(char *rivFile, char *fdrFile, char *rivShpFile, char *rivDbfFile);
