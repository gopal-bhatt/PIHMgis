int streamSegmentation(char *rivFile, char *fdrFile, char *segFile, char *nodeFile);
