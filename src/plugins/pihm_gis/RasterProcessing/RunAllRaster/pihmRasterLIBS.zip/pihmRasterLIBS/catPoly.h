int catchmentPoly(char *catFile, char *nodeFile, char *shpFile, char *dbfFile);
