int setdir(char *demfile, char *angfile, char *slopefile, char *pfile);
int setdird8(char *demfile, char *pfile, char *slopefile);
