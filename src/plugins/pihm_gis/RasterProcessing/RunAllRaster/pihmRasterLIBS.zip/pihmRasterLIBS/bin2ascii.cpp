#include "bin2ascii.h"

int main(){
	bin2ascii("dem1/w001001.adf", "test.asc");
	return(1);
}
