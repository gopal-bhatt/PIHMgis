int aread8(char *pfile,char *afile, double x, double y, int doall);
