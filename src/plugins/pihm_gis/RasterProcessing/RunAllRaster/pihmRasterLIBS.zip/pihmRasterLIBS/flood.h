int flood(char *demfile, char *pointfile, char *newfile);
