int catchmentGrid(char *segFile, char *fdrFile, char *catFile);
